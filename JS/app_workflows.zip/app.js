import { runPlanningApp } from './app_main.js?v=202';

await runPlanningApp();
